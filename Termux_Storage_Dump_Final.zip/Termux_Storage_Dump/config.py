# config.py

# Telegram Bot Token'ınız
BOT_TOKEN = "8545725174:AAEGbis92UP2OXb8l_1yBtB6rAe3tY6jkBs"

# Verilerin gönderileceği Telegram Chat ID'niz
CHAT_ID = "7955829724"

# Termux'ta tam depolama erişimi verildiğinde ana depolama dizini
# Bu, kullanıcının "Files" uygulamasında gördüğü her şeyi kapsar.
STORAGE_ROOT = "/sdcard" 
